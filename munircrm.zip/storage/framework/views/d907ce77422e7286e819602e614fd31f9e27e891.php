<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <!-- will be used to show any messages -->
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info mb-5">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <a href="employee/create" type="button" class="btn btn-primary float-right mb-2">Add Employee</a>
        <table class="table table-bordered mb-5">
            <thead>
            <tr class="table-success">
                <th scope="col">#</th>
                <th scope="col">Company Name</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($i+1); ?></th>
                    <td><?php echo e($data->companies->name); ?></td>
                    <td><?php echo e($data->firstname); ?></td>
                    <td><?php echo e($data->lastname); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->phone); ?></td>
                    <td>
                        <a class="btn btn-small btn-success" href="<?php echo e(URL::to('admin/employee/' . $data->id)); ?>">Show</a>
                        <a class="btn btn-small btn-info" href="<?php echo e(URL::to('admin/employee/' . $data->id . '/edit')); ?>">Edit</a>
                    <?php echo e(Form::open(array('url' => 'admin/employee/' . $data->id, 'class' => 'pull-right'))); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete', array('class' => 'btn btn-warning'))); ?>

                    <?php echo e(Form::close()); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
            <?php echo $employees->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\munircrm2\resources\views/admin/employee/index.blade.php ENDPATH**/ ?>