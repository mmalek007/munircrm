<?php $__env->startSection('content'); ?>
    <h1 class="display-6">Create New Employee</h1>

    <hr/>

    <!-- if validation in the controller fails, show the errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-5">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Open the form with the store function route. -->
    <?php echo e(Form::open(['action' => 'App\Http\Controllers\Admin\EmployeeController@store'])); ?>


    <!-- Include the CRSF token -->
    <?php echo e(Form::token()); ?>

    <div class="form-group">
    <?php echo e(Form::label('company_id', 'Company')); ?>

    <?php echo Form::select('company_id', $companies, null, ['class' => 'form-control']); ?>

    </div>

    <!-- build our form inputs -->
    <div class="form-group">
        <?php echo e(Form::label('firstname', 'First Name')); ?>

        <?php echo e(Form::text('firstname', Request::old('firstname'), ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('lastname', 'Last Name')); ?>

        <?php echo e(Form::text('lastname', Request::old('lastname'), ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('email', 'E-Mail Address')); ?>

        <?php echo e(Form::text('email', Request::old('email'), ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('phone', 'Phone Number')); ?>

        <?php echo e(Form::text('phone', Request::old('phone'), ['class' => 'form-control'])); ?>

    </div>
    <!-- build the submission button -->
    <?php echo e(Form::submit('Create!', ['class' => 'btn btn-primary'])); ?>

    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\munircrm2\resources\views/admin/employee/create.blade.php ENDPATH**/ ?>