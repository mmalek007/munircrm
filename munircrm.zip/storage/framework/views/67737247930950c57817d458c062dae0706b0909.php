<?php $__env->startSection('content'); ?>
    <h1 class="display-6">Company Details</h1>

    <hr/>

    <dl>
        <dt>Logo</dt>
        <dd><img src="<?php echo e(url('public/storage/'.$company->logo)); ?>" width="100" height="100" /></dd>

        <dt>Company Name</dt>
        <dd><?php echo e($company->name); ?></dd>

        <dt>Email</dt>
        <dd><?php echo e($company->email); ?></dd>

        <dt>Website</dt>
        <dd><?php echo e($company->website); ?></dd>

    </dl>

    <div class="d-flex">
        <a class="btn btn-small btn-info" href="<?php echo e(URL::to('admin/company/' . $company->id . '/edit')); ?>">Edit</a>
        <?php echo e(Form::open(array('url' => 'admin/company/' . $company->id, 'class' => 'pull-right'))); ?>

        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <?php echo e(Form::submit('Delete', array('class' => 'btn btn-warning'))); ?>

        <?php echo e(Form::close()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\munircrm2\resources\views/admin/company/show.blade.php ENDPATH**/ ?>