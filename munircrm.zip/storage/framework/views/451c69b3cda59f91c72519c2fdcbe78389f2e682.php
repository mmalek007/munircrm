<?php $__env->startSection('content'); ?>
    <h1 class="display-6">Employee Details</h1>

    <hr/>

    <dl>
        <dt>Company</dt>
        <dd><?php echo e($employee->companies->name); ?></dd>

        <dt>First Name</dt>
        <dd><?php echo e($employee->firstname); ?></dd>

        <dt>Last Name</dt>
        <dd><?php echo e($employee->lastname); ?></dd>

        <dt>Email</dt>
        <dd><?php echo e($employee->email); ?></dd>

        <dt>Phone</dt>
        <dd><?php echo e($employee->phone); ?></dd>

    </dl>

    <div class="d-flex">
        <a href="<?php echo e(URL::to('admin/employee/' . $employee->id . '/edit')); ?>" class="btn btn-primary m-1">Edit</a>
        <?php echo e(Form::open(array('url' => 'admin/employee/' . $employee->id, 'class' => 'pull-right'))); ?>

        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <?php echo e(Form::submit('Delete', array('class' => 'btn btn-warning'))); ?>

        <?php echo e(Form::close()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\munircrm2\resources\views/admin/employee/show.blade.php ENDPATH**/ ?>