<?php $__env->startSection('content'); ?>
    <h1 class="display-6">Create New Company</h1>

    <hr/>

    <!-- if validation in the controller fails, show the errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-5">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Open the form with the store function route. -->
    <?php echo e(Form::open(['action' => 'App\Http\Controllers\Admin\CompanyController@store','enctype'=>"multipart/form-data"])); ?>


    <!-- Include the CRSF token -->
    <?php echo e(Form::token()); ?>



    <!-- build our form inputs -->
    <div class="form-group">
        <?php echo e(Form::label('name', 'Company Name')); ?>

        <?php echo e(Form::text('name', Request::old('name'), ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('email', 'E-Mail Address')); ?>

        <?php echo e(Form::text('email', Request::old('email'), ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('logo', 'Logo')); ?>

        <?php echo e(Form::file('logo', ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('website', 'Website')); ?>

        <?php echo e(Form::text('website', Request::old('website'), ['class' => 'form-control'])); ?>

    </div>
    <!-- build the submission button -->
    <?php echo e(Form::submit('Create!', ['class' => 'btn btn-primary'])); ?>

    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\munircrm2\resources\views/admin/company/create.blade.php ENDPATH**/ ?>