<?php $__env->startSection('content'); ?>
    <h1 class="display-6">Update Company</h1>

    <hr/>

    <!-- if validation in the controller fails, show the errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-5">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Open the form with the update function route. -->
    <?php echo e(Form::open(['action' => ['\App\Http\Controllers\Admin\CompanyController@update',$company->id], 'method' => 'put','enctype'=>"multipart/form-data"])); ?>

        <?php echo e(Form::hidden('id',$company->id)); ?>

    <!-- build our form inputs -->
    <div class="form-group">
        <?php echo e(Form::label('name', 'Company Name')); ?>

        <?php echo e(Form::text('name', $company->name, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('email', 'E-Mail Address')); ?>

        <?php echo e(Form::text('email', $company->email, ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('logo', 'Logo')); ?>

        <img src="<?php echo e(url('public/storage/'.$company->logo)); ?>" width="100" height="100" />
        <?php echo e(Form::file('logo', ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('website', 'Website')); ?>

        <?php echo e(Form::text('website', $company->website, ['class' => 'form-control'])); ?>

    </div>
    <!-- build the submission button -->
    <?php echo e(Form::submit('Update!', ['class' => 'btn btn-primary'])); ?>

    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\munircrm2\resources\views/admin/company/edit.blade.php ENDPATH**/ ?>